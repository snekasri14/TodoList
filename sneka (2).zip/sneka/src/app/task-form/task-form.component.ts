import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import{FormsModule } from '@angular/forms';
@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './task-form.component.html',
  styleUrl: './task-form.component.css'
})
export class TaskFormComponent implements  OnInit{
  @Input() taskList: any;
  newTask : any;
  constructor() { }
  ngOnInit(): void{
 }

 addTodo(){
  this.taskList.unshift(this.newTask);
  
  this.newTask = '';
 }
}
