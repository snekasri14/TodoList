import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css'
})
export class TaskListComponent implements OnInit {
 @Input() tasks: any; 
 searchText: any = '' ;
  constructor() { }

  ngOnInit(): void {
    
  }
removeTask(index: number) {
  this.tasks.splice(index, 1)
}
}
